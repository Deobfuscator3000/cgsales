Q.1/09

This CD contains the latest update to the AFD Postcode software.

Installation instructions:

Run setupafd.exe from the CD to update the software and license to the
latest release and expiry date.

The files can be copied to a network location provided they stay in the
same folder structure as on this CD.

-----------------
01624 811712
support@afd.co.uk
08/01/2009
-----------------

