Q.1/16

This folder contains the latest update to the AFD Postcode software.

Installation instructions:

Run setupafd.exe to update the software and license to the
latest release and expiry date.

The files can be copied to a network location provided they stay in the
same folder structure.

Account Code: CASHG02

Serial No: 814114

Installation Password: LG6T 6HA 4A

